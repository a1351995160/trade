# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.10322782600000013 |
| 最大回撤（比例） | 0.07290335999999997 |
| 总费用（元） | 381.5287 |
| 交易计数（原口径） | 26 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\52925275c2c99149639b2c30b5e3ca4f441d9fb0bbb910db3aa37c586c2ba009\account\ACCEPT_A_MA10_COST_STOP_STRESS_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\52925275c2c99149639b2c30b5e3ca4f441d9fb0bbb910db3aa37c586c2ba009\account\ACCEPT_A_MA10_COST_STOP_STRESS_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\52925275c2c99149639b2c30b5e3ca4f441d9fb0bbb910db3aa37c586c2ba009\\account\\ACCEPT_A_MA10_COST_STOP_STRESS_RESULT.json', 'sha256': 'b58155c02d940463c04484f2f0dbacc9f95d20a494c3f1eeb48bd17525365e52'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
