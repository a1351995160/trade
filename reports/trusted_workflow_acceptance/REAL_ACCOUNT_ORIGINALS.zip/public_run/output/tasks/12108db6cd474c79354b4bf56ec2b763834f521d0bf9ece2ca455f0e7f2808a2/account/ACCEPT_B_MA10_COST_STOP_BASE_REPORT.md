# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.07934507400000035 |
| 最大回撤（比例） | 0.10575227797023601 |
| 总费用（元） | 337.8963 |
| 交易计数（原口径） | 36 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_BASE_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_BASE_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\\account\\ACCEPT_B_MA10_COST_STOP_BASE_RESULT.json', 'sha256': '62ed5694f6d910d984984b7bf65b347449ddd22d1bb738b35e8f523290e792a2'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
