# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.0625046920000003 |
| 最大回撤（比例） | 0.10589797070082074 |
| 总费用（元） | 520.2754 |
| 交易计数（原口径） | 36 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_STRESS_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_STRESS_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\\account\\ACCEPT_B_MA10_COST_STOP_STRESS_RESULT.json', 'sha256': '6e715b9aeafb4b83f8bd39d2e23d909b3adb41e73071ac059da6dbe7d2552af6'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
