# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.05496980000000007 |
| 最大回撤（比例） | 0.16315233943659657 |
| 总费用（元） | 15.0 |
| 交易计数（原口径） | 3 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_BENCHMARK_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\account\ACCEPT_B_MA10_COST_STOP_BENCHMARK_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\12108db6cd474c79354b4bf56ec2b763834f521d0bf9ece2ca455f0e7f2808a2\\account\\ACCEPT_B_MA10_COST_STOP_BENCHMARK_RESULT.json', 'sha256': '8ffa428d042ec62ed27f0199d84c4bd5d9ae1c81f355e7cd2d91ca3f50bd22a5'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
