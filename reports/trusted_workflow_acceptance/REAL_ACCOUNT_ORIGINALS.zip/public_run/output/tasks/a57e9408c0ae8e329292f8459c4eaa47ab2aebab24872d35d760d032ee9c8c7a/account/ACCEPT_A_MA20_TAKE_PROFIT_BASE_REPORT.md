# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.02003844400000032 |
| 最大回撤（比例） | 0.10287815599999972 |
| 总费用（元） | 216.8487 |
| 交易计数（原口径） | 23 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\a57e9408c0ae8e329292f8459c4eaa47ab2aebab24872d35d760d032ee9c8c7a\account\ACCEPT_A_MA20_TAKE_PROFIT_BASE_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\a57e9408c0ae8e329292f8459c4eaa47ab2aebab24872d35d760d032ee9c8c7a\account\ACCEPT_A_MA20_TAKE_PROFIT_BASE_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\a57e9408c0ae8e329292f8459c4eaa47ab2aebab24872d35d760d032ee9c8c7a\\account\\ACCEPT_A_MA20_TAKE_PROFIT_BASE_RESULT.json', 'sha256': '505150247147f3e08e0d1b8f9dc98e4ffffe6989155918394a7070957c1fff4a'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
