# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.08668184400000034 |
| 最大回撤（比例） | 0.07395430999999986 |
| 总费用（元） | 135.7578 |
| 交易计数（原口径） | 14 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\account\ACCEPT_B_DUAL_MA_TRAILING_BASE_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\account\ACCEPT_B_DUAL_MA_TRAILING_BASE_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\\account\\ACCEPT_B_DUAL_MA_TRAILING_BASE_RESULT.json', 'sha256': 'abb4383a3f3319830fe44c1ab79aca969d34ef1fc6e9066b24b6d67c16a813fb'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
