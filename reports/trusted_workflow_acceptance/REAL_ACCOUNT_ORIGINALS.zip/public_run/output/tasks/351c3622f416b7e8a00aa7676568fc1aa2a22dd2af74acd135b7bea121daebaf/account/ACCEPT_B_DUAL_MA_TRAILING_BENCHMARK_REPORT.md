# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.05496980000000007 |
| 最大回撤（比例） | 0.16315233943659657 |
| 总费用（元） | 15.0 |
| 交易计数（原口径） | 3 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\account\ACCEPT_B_DUAL_MA_TRAILING_BENCHMARK_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\account\ACCEPT_B_DUAL_MA_TRAILING_BENCHMARK_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\351c3622f416b7e8a00aa7676568fc1aa2a22dd2af74acd135b7bea121daebaf\\account\\ACCEPT_B_DUAL_MA_TRAILING_BENCHMARK_RESULT.json', 'sha256': 'aac96da853f87fc6e23385951cbaa9cde8e1138aef51850fc5b75a78ccab15e5'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
