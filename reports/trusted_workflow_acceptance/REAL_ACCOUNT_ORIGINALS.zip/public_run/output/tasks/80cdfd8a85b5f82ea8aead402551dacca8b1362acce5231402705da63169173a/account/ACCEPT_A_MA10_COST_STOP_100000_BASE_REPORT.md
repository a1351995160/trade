# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.11766874699999996 |
| 最大回撤（比例） | 0.07010787899999993 |
| 总费用（元） | 491.3653 |
| 交易计数（原口径） | 26 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\account\ACCEPT_A_MA10_COST_STOP_100000_BASE_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\account\ACCEPT_A_MA10_COST_STOP_100000_BASE_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\\account\\ACCEPT_A_MA10_COST_STOP_100000_BASE_RESULT.json', 'sha256': '25698f247c974faa89b480e9c6b7dc9f61d522416528662a64640a441ec92b57'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
