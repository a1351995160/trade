# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.10304217199999988 |
| 最大回撤（比例） | 0.07439615799999999 |
| 总费用（元） | 739.8028 |
| 交易计数（原口径） | 26 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\account\ACCEPT_A_MA10_COST_STOP_100000_STRESS_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\account\ACCEPT_A_MA10_COST_STOP_100000_STRESS_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\80cdfd8a85b5f82ea8aead402551dacca8b1362acce5231402705da63169173a\\account\\ACCEPT_A_MA10_COST_STOP_100000_STRESS_RESULT.json', 'sha256': '2ea18c4aa7e542166766521d84d6fd427acff674f6a1fa75a1392ed2b101e389'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
