# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.12305482199999962 |
| 最大回撤（比例） | 0.04775330044868564 |
| 总费用（元） | 89.5489 |
| 交易计数（原口径） | 9 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\814ca737dc2b44e3d9acf9c61f53c7f3dfdbdb97218d47cd9c5de5a848656c5e\account\ACCEPT_A_DUAL_MA_TRAILING_BASE_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\814ca737dc2b44e3d9acf9c61f53c7f3dfdbdb97218d47cd9c5de5a848656c5e\account\ACCEPT_A_DUAL_MA_TRAILING_BASE_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\814ca737dc2b44e3d9acf9c61f53c7f3dfdbdb97218d47cd9c5de5a848656c5e\\account\\ACCEPT_A_DUAL_MA_TRAILING_BASE_RESULT.json', 'sha256': '7e1453a796f75226d06f93e076051560dfc527846fb1374bf32d7e9cc281d1d3'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
