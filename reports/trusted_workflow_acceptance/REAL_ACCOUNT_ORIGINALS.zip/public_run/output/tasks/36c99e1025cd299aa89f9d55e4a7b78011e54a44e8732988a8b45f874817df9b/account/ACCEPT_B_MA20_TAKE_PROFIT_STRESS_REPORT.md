# STRATEGY_INTERFACE_V1

阶段：ACCOUNT_BACKTEST；状态：HISTORICAL_MODELED_ACCOUNT_COMPLETED

| 项目 | 原有结果 |
|---|---|
| 净收益率（比例） | 0.11563399000000008 |
| 最大回撤（比例） | 0.11170316851505502 |
| 总费用（元） | 455.5005 |
| 交易计数（原口径） | 31 |

基准：AVAILABLE
原因：本阶段无拒绝原因
trades：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\36c99e1025cd299aa89f9d55e4a7b78011e54a44e8732988a8b45f874817df9b\account\ACCEPT_B_MA20_TAKE_PROFIT_STRESS_RESULT.json#fills
ledger：E:\worktrees\trusted-strategy-research\trade-system-contract-port-v1\reports\trusted_workflow_acceptance\public_run\output\tasks\36c99e1025cd299aa89f9d55e4a7b78011e54a44e8732988a8b45f874817df9b\account\ACCEPT_B_MA20_TAKE_PROFIT_STRESS_RESULT.json#final_account_checkpoint
source_result：{'path': 'E:\\worktrees\\trusted-strategy-research\\trade-system-contract-port-v1\\reports\\trusted_workflow_acceptance\\public_run\\output\\tasks\\36c99e1025cd299aa89f9d55e4a7b78011e54a44e8732988a8b45f874817df9b\\account\\ACCEPT_B_MA20_TAKE_PROFIT_STRESS_RESULT.json', 'sha256': 'e728b528fd409a7083a790b63d60bf16c8e4f13bec2a89ff823be8b8946fa555'}

限制：
- 模型结果；未自动授予统计资格。
- 日期一致不代表实际风险暴露一致；不据此直接宣称alpha。
